Delivery Order QR Generator v0.2
================================

หน้าที่
- เลือก Delivery Order แบบ PDF ที่สแกนมา
- ตรวจรูปแบบ DNTH, JATH และ JTCS อัตโนมัติ
- DNTH: CURRENT QTY + NO. OF BOX
- JATH: TOTAL Q'TY + ORDER KANBANS
- JTCS: TOTAL QUANTITY + No. OF CONTAINERS
- ให้ผู้ใช้ตรวจ/แก้ค่าก่อนสร้าง
- สร้าง PDF ฉบับใหม่และเพิ่ม QR ในหน้าสรุปเดิม ไม่เพิ่มหน้ากระดาษ
- QR ใช้กับ Check Tag_RS v0.19.0

ติดตั้งครั้งแรก
1. ติดตั้ง Python 3.11 หรือใหม่กว่า และเลือก Add Python to PATH
2. ติดตั้ง Tesseract OCR for Windows
3. ดับเบิลคลิก install.bat

ใช้งาน
1. ดับเบิลคลิก run.bat
2. กด "เลือก Delivery Order PDF"
3. ตรวจ Part No., Current QTY และ NO. OF BOX
4. ดับเบิลคลิกรายการหากต้องแก้ค่า
5. กด "สร้าง PDF พร้อม QR"

กฎความปลอดภัย
- โปรแกรมไม่แก้ไฟล์ PDF ต้นฉบับ
- รายการ Current QTY = 0 จะแสดงคำเตือนและไม่สร้าง QR ใช้ส่งงาน
- ถ้า OCR อ่านข้อมูลไม่ครบ โปรแกรมจะไม่เดาค่า ให้ผู้ใช้ตรวจ/แก้ก่อน
- PM75 ตรวจ Part No. ใน QR กับ KANBAN ก่อนรับจำนวน

รูปแบบ QR
CHECKTAGRS|DO|PART=TG053661-7151|QTY=1100|BOX=11
